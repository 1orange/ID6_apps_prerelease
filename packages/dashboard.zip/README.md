# 340i native dashboard update

ShiftDeck targets a 20 ms RPM polling loop, with vehicle speed sampled every 65 ms. It schedules a screen update every 16 ms while visible and interpolates RPM for up to 50 ms after a new reading. Fresh measured values still drive the shift alert directly.

BoostDeck targets a 35 ms fast scan for boost, AFR, timing, rail pressure and oil pressure. Temperatures retain a 2 second schedule and Active Ethanol a 5 second schedule. A scan can take longer when the DME is slow or another app needs the gateway.

Both apps offer Imperial and Metric under OPTIONS. ShiftDeck uses mph or km/h. BoostDeck uses psi and Fahrenheit or bar and Celsius. MHD+ Suite uses Off and On tiles under Max Cooling. A tile lights up after the DME accepts the request. The existing live-RPM condition and commands are retained.

The bundled Engine Fault Codes also includes the earlier clear-response and extended-session improvements. Follow AgentReadMe.md in the GitHub repository for setup and verification. Restart iDrive while parked after verifying the files.

BoostDeck, ShiftDeck, MHD+ Suite and Engine Fault Codes include the MOST diagnostic fallback from PR #9. The workers use HSFZ first. To configure a different gateway, place its IPv4 address in gateway-ip.txt beside the worker's app manifest.

Exhaust Flap is an optional dashboard menu. It controls the factory exhaust flap through HSFZ. The launcher reads gateway-ip.txt and defaults to 169.254.21.3.
