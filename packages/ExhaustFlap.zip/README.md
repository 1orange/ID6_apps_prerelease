# 740i Exhaust Flap 

Exhaust Flap controller, it actuate the oem exhaust flap (OPEN | CLOSE | AUTO)